import Navbarr from "./Navbarr"

export default function Home() {
    
  return (
    <div>
      <Navbarr />
     <h1>Content Yet to be added</h1> 
    </div>

  )
}
